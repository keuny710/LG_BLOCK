import torch

def train_net(buffer, net, target_net, optimizer, batch_size, gamma, use_mask=False):
        if len(buffer) < batch_size:
            return None

        state, action, reward, next_state, done, mask = buffer.sample(batch_size)

        state      = torch.autograd.Variable(torch.FloatTensor(state))
        next_state = torch.autograd.Variable(torch.FloatTensor(next_state))
        action     = torch.autograd.Variable(torch.LongTensor(action))
        reward     = torch.autograd.Variable(torch.FloatTensor(reward))
        done       = torch.autograd.Variable(torch.FloatTensor(done))
        if use_mask:
            mask       = torch.autograd.Variable(torch.FloatTensor(mask))

        q_values      = net(state)
        next_q_values = net(next_state)
        next_q_state_values = target_net(next_state)


        q_value = q_values.gather(1,action.unsqueeze(1)).squeeze(1)

        next_q_value = next_q_state_values.gather(1, torch.max(next_q_values, 1)[1].unsqueeze(1)).squeeze(1)

        expected_q_value = reward + gamma * next_q_value * (1 - done)

        loss = (q_value - torch.autograd.Variable(expected_q_value.data)).pow(2).mean()

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()


        return loss
