import math, random
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import torch.autograd as autograd
import pandas as pd
import copy
import os


class EventDecisionNN(nn.Module):
    def __init__(self, num_inputs):
        super(EventDecisionNN, self).__init__()
        self.layers = nn.Sequential(
            nn.Linear(num_inputs, 512),
            nn.ReLU(),
            nn.Linear(512, 256),
            nn.ReLU(),
            nn.Linear(256, 128),
            nn.ReLU(),
            nn.Linear(128, 64),
            nn.Sigmoid(),
            nn.Linear(64, 4),
            nn.Softmax()
        )
        self.num_actions = 4

    def forward(self, x):
        return self.layers(x)

    # Actions
    # 0: check
    # 1: process
    # 2: stop
    # 3: change
    def get_action(self, state, mask, epsilon=0.0, submission=None, t=None, line=None):
        if submission is not None:
            line_ = 'A' if line == 0 else 'B'
            event = submission.loc[t,f'Event_{line_}']
            if 'PROCESS' == event:
                action = 1
            elif 'CHANGE' in event :
                action = 3
            elif 'CHECK' in event:
                action = 0
            elif 'STOP' == event:
                action = 2
            else:
                raise ValueError("Invalid Event")
        else:
            if random.random() > epsilon:
                state = torch.autograd.Variable(torch.FloatTensor(state).unsqueeze(0))  # adds extra dim at front
                q_value = self.forward(state)
                masked_q_value = q_value.detach() * mask 
                if len(masked_q_value) > 1 :
                    if mask[1] > 0 :
                        masked_q_value[1] += 0.99
                if len(masked_q_value) == 1:
                    if mask[1] > 0 :
                        masked_q_value[0][1] += 0.99
                action = torch.argmax(masked_q_value).tolist()
            else:
                q_value = torch.rand_like(mask)
                masked_q_value = q_value * mask
                if len(masked_q_value) > 1 :
                    if mask[1] > 0 :
                        masked_q_value[1] += 0.99
                if len(masked_q_value) == 1 :
                    if mask[1] > 0 :
                        masked_q_value[0][1] += 0.99
                action = torch.argmax(masked_q_value).tolist()
        return action


class BrickTypeNN(nn.Module):
    def __init__(self, num_inputs):
        super(BrickTypeNN, self).__init__()
        self.layers = nn.Sequential(
            nn.Linear(num_inputs, 50),
            nn.ReLU(),
            nn.Linear(50, 50),
            nn.Sigmoid(),
            nn.Linear(50, 4),
            nn.Softmax()
        )
        self.num_actions = 4

    def forward(self, x):
        return self.layers(x)

    # Actions
    # Block type number (1~4)
    def get_action(self, state, mask, env_brick_mask, env_t, epsilon=0.0, submission=None, t=None, line=None):
        if submission is not None:
            line_ = 'A' if line == 0 else 'B'
            event = submission.loc[t,f'Event_{line_}']
            if 'CHANGE' in event or 'CHECK' in event:
                action = int(event[-1])
            else:
                raise ValueError('Event is not CHANGE')
        else:
            new_mask = env_brick_mask[env_t] * mask
            if np.all(new_mask == 0): 
                new_mask = mask
            if random.random() > epsilon:
                state = torch.autograd.Variable(torch.FloatTensor(state).unsqueeze(0))  # adds extra dim at front
                q_value = self.forward(state)
                masked_q_value = q_value.detach() * new_mask
                action = torch.argmax(masked_q_value).tolist() + 1
            else:
                q_value = torch.rand_like(torch.tensor(mask, dtype=torch.float))
                masked_q_value = q_value * new_mask
                action = torch.argmax(masked_q_value).tolist() + 1
        return action        

class MoldingAmountNN(nn.Module):
    def __init__(self, num_inputs):
        super(MoldingAmountNN, self).__init__()
        self.num_actions = 13
        self.layers = nn.Sequential(
            nn.Linear(num_inputs, 128),
            nn.ReLU(),
            nn.Linear(128, 64),
            nn.Sigmoid(),
            nn.Linear(64, self.num_actions),
            nn.Softmax()
        )

    def forward(self, x):
        return self.layers(x) 
                              
    def get_action(self, state, epsilon=0.0, submission=None, t=None, line=None):
        if submission is not None:
            line_ = 'A' if line == 0 else 'B'
            mol_num = submission.loc[t,f'MOL_{line_}']
            action = mol_num
            if action >= 5.7:
                return action, 12
            else:
                return action, action * 2
        else:       
            if random.random() > epsilon:
                state = torch.autograd.Variable(torch.FloatTensor(state).unsqueeze(0))  # adds extra dim at front
                q_value = self.forward(state)
                # q_value = q_value.Softmax(dim=1)
                action = torch.argmax(q_value).tolist()
            else:
                action = np.random.randint(0, self.num_actions)
        if action == 12:
            return 5.8, action
        else:
            return action / 2, action

def init_weights(m):
    torch.manual_seed(1111)
    torch.cuda.manual_seed_all(1111)
    std = 0.01
    if type(m) == nn.Linear:
        m.weight.data.normal_(0,std)
        m.bias.data.fill_(0)