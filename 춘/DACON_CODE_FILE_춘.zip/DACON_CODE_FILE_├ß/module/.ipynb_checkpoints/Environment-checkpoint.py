import math, random
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import torch.autograd as autograd
import pandas as pd
import copy
import os
from module.sim_block import Simulator
from module.Data import Data

simulator = Simulator()

class LEGOEnv:

    def __init__(self):
        
        self.init_prt_2 = 258

        self._submission = pd.read_csv('./data/sample_submission.csv')
        self._max_count = pd.read_csv('./data/max_count.csv')
        self._stock = pd.read_csv('./data/stock.csv')
        self._order = pd.read_csv('./data/order.csv')
        self._changetime = pd.read_csv('./data/change_time.csv')
        self._cutyield = pd.read_csv('./data/cut_yield.csv')

        # Time period (inhours)
        self.t = 0

        # Max time (91 days)
        self.t_max = 91 * 24

        # Type of block: 1~4
        self.blk_types = [1, 2, 3, 4]

        # Total order in bricks
        self.N = self._order[[f'BLK_{blk_type}' for blk_type in self.blk_types]].sum().sum()

        # Total time span in hours
        self.M = 91 * 24

        data = Data()
        self.check_per_hour = data.check_per_hour
        self.brick_mask = data.brick_mask

        self.mol = {1:0, 2:0, 3:0, 4:0}
        self.line_make_type = {0 : 2 , 1: 2 }

        self.preprocessing()
        
        # temporary buffer
        self.tempbuffer_event_action = []
        self.tempbuffer_type_action = []  
        self.tempbuffer_molding_action = []

        # masks for current states
        self._mask = {
            'CHECK_MAX': torch.tensor([0, 1, 0, 0], dtype=torch.float),  # PROCESS
            'PROCESS': torch.tensor([1, 1, 0, 0], dtype=torch.float),  # CHECK, PROCESS, STOP, CHANGE
            'PROCESS_NOCHANGE': torch.tensor([1, 1, 0, 0], dtype=torch.float),  # CHECK, PROCESS, STOP
            'PROCESS_CHANGE': torch.tensor([0, 1, 0, 0], dtype=torch.float),  # PROCESS, CHANGE
            'PROCESS_MAX': torch.tensor([1, 0, 0, 0], dtype=torch.float),  # CHECK, STOP
            'STOP': torch.tensor([1, 0, 0, 0], dtype=torch.float),  # CHECK, STOP
            'STOP_MAX': torch.tensor([1, 0, 0, 0], dtype=torch.float),  # CHECK
            'STOP_ONLY': torch.tensor([0, 0, 0, 0], dtype=torch.float), # STOP
            'CHANGE_MAX': torch.tensor([0, 1, 0, 0], dtype=torch.float),  # PROCESS
            'CHECK_ONLY': torch.tensor([1, 0, 0, 0], dtype=torch.float),  # CHECK
            'PROCESS_ONLY': torch.tensor([0, 1, 0, 0], dtype=torch.float),  # PROCESS
            'CHANGE_ONLY': torch.tensor([0, 0, 0, 0], dtype=torch.float),  # CHANGE
            'NOTHING': torch.tensor([0, 0, 0, 0], dtype=torch.float)  # NOTHING
        }

        self._event_action_to_name = {
            0: 'CHECK',
            1: 'PROCESS',
            2: 'STOP',
            3: 'CHANGE'
        }

        self.reset()

    def reset(self):
        self.ts = 0
        self.t = 0
        self.init_prt_2 = 258
        self.mol = {1:0, 2:0, 3:0, 4:0}
        self.line_make_type = {0 : 2 , 1: 2 }
        
        # temporary buffer
        self.tempbuffer_event_action = []
        self.tempbuffer_type_action = []  
        self.tempbuffer_molding_action = []
        
        # State: 0:'CHECK', 1:'PROCESS', 2:'STOP', or 3:'CHANGE'
        self.line_states = [0, 0]  # initial state

        # Block types of lines
        self.line_types = [1, 1]

        # Action lists of lines
        self.line_eventlists = [
            [], []
        ]

        # Hours in the current state
        self.line_Ts = [0, 0]
        self.state_line_Ts = [0, 0] 
        
        # Remaining hours for CHANGE
        self.line_CTs = [0, 0]
        self.state_line_CTs = [0, 0]

        # Lists of items under the molding process
        # Everyhour the line is PROCESS an item (brick type, amount) is appended.
        self.line_mold_process = [
            [], []
        ]

        # List of items after molding process
        self.mold_completed = {
            blk_type: [] for blk_type in self.blk_types
        }

        # Append initial mold stock
        for blk_type in self.blk_types:
            mold_stock = self._stock.loc[0][f'MOL_{blk_type}']
            if mold_stock > 0:
                self.mold_completed[blk_type].append(
                    [0, mold_stock]
                )

        # Initial brick inventory
        # [61158, 87279, 0, 0]
        self.initial_inventory = [
            self._stock.loc[0][f'BLK_{blk_type}'] for blk_type in self.blk_types
        ]

        # Daily brick inventory
        self.daily_inventory = []

        # Brick surplus/shortage on days with positive orders
        self.orderday_diff = []

        # Total surplus (p)
        self.tot_surplus = 0

        # Total shortage (q)
        self.tot_shortage = 0

        # Total CHANGE hours (c)
        self.tot_change_hours = 0

        # Total CHANGE times (c_n)
        self.tot_change_times = 0

        # Total STOP hours (s)
        self.tot_stop_hours = 0

        # Total STOP times (s_n)
        self.tot_stop_times = 0

        # Total orders by the time t
        self.tot_order = 0

        # Set initial states
        # Line A: CHECK, Blick type 2
        # Line B: CHECK, Blick type 2
        self.apply_action(0, 0, 2, None)
        self.apply_action(1, 0, 2, None)

        return self.get_state()

    def preprocessing(self):
        # Make change time dic
        changetime_dic = {
            i: {j: 0 for j in self.blk_types if i != j}
            for i in self.blk_types
        }

        for row in self._changetime.iterrows():
            i = int(row[1]['from'][-1])
            j = int(row[1]['to'][-1])

            changetime_dic[i][j] = row[1]['time']

        self.changetime_dic = changetime_dic


        # Prebuild static state information
        self.time_state_dic = {
            t: np.zeros(self.t_max)
            for t in range(self.t_max+1)
        }

        for t in range(self.t_max):
            self.time_state_dic[t][t] = 1

        self.order_state_dic = {
            t: np.array(self._order.loc[t // 24:(t // 24 + 30), 'BLK_1':'BLK_4']).reshape(-1)
            for t in range(self.t_max+1)
        }

        for t in range(self.t_max+1):
            order_state = np.array(self._order.loc[t // 24:(t // 24 + 30), 'BLK_1':'BLK_4']).reshape(-1)
            if len(order_state) < 124:
                order_state = np.concatenate((order_state, np.zeros(124-len(order_state))))
            self.order_state_dic[t] = order_state


    def get_state(self):
        order_state = self.order_state_dic[self.t]

        process_state = np.zeros(4)
        for line in [0,1]:
            if self.line_states[line] == 1:  # PROCESS
                process_state[self.line_types[line] - 1] += 1
                
        if len(self.orderday_diff) == 0:
            diff_state = [0,0,0,0]
        else:
            diff_state = self.orderday_diff[-1]

        return np.concatenate((order_state, process_state, [self.t], self.line_types))


    # Return mask for EventDecisionNN actions
    def get_avail_states_mask(self):
        masks = []
        for state, T, CT in zip(self.line_states, self.line_Ts, self.line_CTs):
            if state == 0:
                if T == 28:  # CHECK
                    masks.append(self._mask['CHECK_MAX'])
                else:
                    masks.append(self._mask['CHECK_ONLY'])
            elif state == 1:  # PROCESS
                if T >= 140:  # Maximum limit of PROCESS state
                    masks.append(self._mask['PROCESS_MAX'])
                elif T < 98:
                    masks.append(self._mask['PROCESS_CHANGE'])
                elif 98 <= T <= 140 - 13:  # 13 is the maximum change time
                    masks.append(self._mask['PROCESS'])
                else:
                    masks.append(self._mask['PROCESS_NOCHANGE'])
            elif state == 2: # STOP
                if T < 29:
                    masks.append(self._mask['STOP_ONLY'])
                elif T == 192: # Maximum limit of STOP state
                    masks.append(self._mask['STOP_MAX'])
                else:
                    masks.append(self._mask['STOP'])
            elif state == 3:
                if CT == 0:  # CHANGE
                    masks.append(self._mask['CHANGE_MAX'])
                else:
                    masks.append(self._mask['CHANGE_ONLY'])
            else:
                masks.append(0)

        return masks

    def get_reward(self):
        # Score = 50 x F(p, 10N) + 20 x F(q, 10N) + 20 x F(c, M) / (1+0.1 x c_n) + 10 x F(s, M) / (1+0.1 x s_n)
        F = lambda x,a: 1 - x/a if x < a else 0

        score = 50 * F(self.tot_shortage, 10*self.N) + \
            20 * F(self.tot_surplus, 10*self.N) + \
            20 * F(self.tot_change_hours, self.M) / (1+0.1 * self.tot_change_times) + \
            10 * F(self.tot_stop_hours, self.M) / (1+0.1 * self.tot_stop_times)
        
        return score / 100


    def is_event_decision_time(self, submission=None):
        if submission is None:
            need_decision = []
            for state, T, CT in zip(self.line_states, self.line_Ts, self.line_CTs):
                if state == 0 and T == 28:  # CHECK
                    need_decision.append(True)
                elif state == 1 and T <= 140:  # PROCESS
                    need_decision.append(True)
                elif state == 2 and T <= 192:  # STOP
                    need_decision.append(True)
                elif state == 3 and CT == 0:  # CHANGE
                    need_decision.append(True)
                else:
                    need_decision.append(False)
            return need_decision
        else:
            return [True, True]

    def is_molding_decision_time(self, submission=None):
        if submission is not None:
            return [True,True]
        else:
            return [
                (state == 1) and (self.t >= 15 * 24)  # PROCESS
                for state in self.line_states
            ]

    def apply_action(self, line, event_action, type_action, mol_action, submission=None):

        reward_1 = 0
        reward_2 = 0
        reward_3 = 0

        if event_action == 1:
            reward_1 += 1
        else:
            reward_1 -= 0

        if type_action is not None:
            if self.brick_mask[self.t][type_action - 1] != 1:
                reward_2 -= 1
            else:
                reward_2 += 0

        diff = self.mol[self.line_make_type[line]] - self.check_per_hour[self.t][self.line_make_type[line] - 1]

        if mol_action is not None:
            if diff > 0 and mol_action == 0:
                reward_3 += 1
            elif diff > 0 and mol_action != 0:
                reward_3 -= 0
            elif diff < -5 and mol_action < 5:
                reward_3 -= 0
            elif diff < -5 and mol_action >= 5:
                reward_3 += 1
            else:
                reward_3 = 0

        if submission is None:
            if mol_action is not None:
                if self.t <= 719:
                    if diff > 0:
                        mol_action = 0
                    elif diff < - 5.8579 :
                        mol_action = 5.8579
                elif 720 <= self.t <=1463:
                    if diff > 0:
                        mol_action = 0
                    elif diff < - 5.8668 :
                        mol_action = 5.8668
                elif self.t>= 1464:
                    if diff > 1:
                        mol_action = 0
                    elif diff < - 5.8757 :
                        mol_action = 5.8757

                if self.line_make_type[line] != 2 and self.t < 23 * 24:
                    mol_action = 0
                if self.line_make_type[line] == 2 and self.mol[self.line_make_type[line]] + mol_action > self.init_prt_2 and self.t < 23*24:
                    mol_action = 0

        # Increase the CHANGE hours/times
        if self.line_states[line] == 3 and event_action == 1:  # end of CHANGE
            self.tot_change_hours += (self.t - self.line_eventlists[line][-1][0])
            self.tot_change_times += 1

        # Increase the STOP hours/times
        if self.line_states[line] == 2 and event_action == 0:  # end of STOP
            self.tot_stop_hours += (self.t - self.line_eventlists[line][-1][0])
            self.tot_stop_times += 1
            
        if type_action is not None:
            self.line_make_type[line] = type_action
            
        self.line_eventlists[line].append((self.t, event_action, type_action, mol_action))

        if event_action is None or event_action == 1:  # PROCESS
            # Append to molding_process lists
            self.line_mold_process[line].append(
                [self.t, self.line_types[line], mol_action]
            )
            if mol_action is not None:
                self.mol[self.line_make_type[line]] += mol_action

        if event_action is not None:
            # Don't reset T if the event is CHANGE related one
            reset_T = (event_action != 3) and not (event_action == 1 and self.line_states[line] == 3)
            self.update_line_state(line, event_action, reset_T)
            if event_action == 3:  # CHANGE
                # Set change time
                self.line_CTs[line] = self.changetime_dic[self.line_types[line]][type_action]

        if type_action is not None:
            self.line_types[line] = type_action

        done = self.t == self.t_max
        after_reward = self.get_reward()

        reward_factor = 1
        ## 이따 얘기해보자
        if done:
            reward_1 = after_reward * reward_factor
            reward_2 = after_reward * reward_factor
            reward_3 = after_reward * reward_factor

        return self.get_state(), reward_1, reward_2, reward_3, done
    
    def state_is_molding_decision_time(self,line, submission):
        if submission:
            return [True]
        else:
            return [
                (self.line_states[line]==1) and (self.ts >= 15 * 24)  # PROCESS
            ]
    
    def state_is_event_decision_time(self, submission=False):
        if submission:
            return [True, True]
        else:
            need_decision = []
            for state, T, CT in zip(self.line_states, self.state_line_Ts, self.state_line_CTs):
                if state == 0 and T == 28:  # CHECK
                    need_decision.append(True)
                elif state == 1 and T <= 140:  # PROCESS
                    need_decision.append(True)
                elif state == 2 and T <= 192:  # STOP
                    need_decision.append(True)
                elif state == 3 and CT == 0:  # CHANGE
                    need_decision.append(True)
                else:
                    need_decision.append(False)

            return need_decision    ## 1X2 
    
    # Proceed time to the next time period required any decisions
    def preceed_time(self, submission=False):
        while self.t < self.t_max:
            self.update_inventory()
            self.t += 1
            for line in [0, 1]:
                self.line_Ts[line] += 1
                if self.line_CTs[line] > 0:
                    self.line_CTs[line] -= 1
            # If any actions needed to proceed
            if np.any(self.is_event_decision_time(submission)) or np.any(self.is_molding_decision_time(submission)):
                break
            if self.t == self.t_max:
                break
        done = self.t == self.t_max
        return self.get_state(), done
    
    def state_preceed_time(self,line):
        self.ts = self.t
        self.state_line_Ts[line] = self.line_Ts[line]
        self.state_line_CTs[line] = self.line_CTs[line]
        while self.ts < self.t_max: 
            self.ts += 1 
            self.state_line_Ts[line] += 1
            if self.state_line_CTs[line] > 0:
                self.state_line_CTs[line] -= 1 
                

            # If any actions needed to proceed
            if np.any(self.state_is_event_decision_time(True)) or np.any(self.state_is_molding_decision_time(line, True)):
                break

            if self.ts == self.t_max:
                break

        return self.get_state_s() 

    # Update inventory
    def update_inventory(self):
        # Update completed mold items
        for line in [0, 1]:
            if len(self.line_mold_process[line]) == 49:
                t, blk_type, mol_amount = self.line_mold_process[line].pop(0)
                if mol_amount is not None:
                    self.mold_completed[blk_type].append(
                        [t, mol_amount * 0.975]
                    )               
        # Update delivery inventory
        if self.is_delivery_time(): 
            if len(self.daily_inventory) == 0: # The first day
                today_inventory = self.initial_inventory
            else:
                today_inventory = self.daily_inventory[-1].copy()  # Get yesterday's inventory
            order = self.get_order_today()
            if sum(order) > 0:
                for blk_type, blk_order in zip(self.blk_types, order):
                    if blk_order > 0:
                        # Get all completed molded items for this type
                        # [[mold_complete_time, mold_amount], ...]
                        mold_completed_of_type = self.mold_completed[blk_type]
                        # mold_sum is total molded items to cut now
                        mold_sum = 0
                        while len(mold_completed_of_type) > 0:
                            if mold_completed_of_type[0][0] > self.t:
                                break
                            mold_sum += mold_completed_of_type[0][1]
                            mold_completed_of_type.pop(0)
                        if mold_sum > 0:
                            blk_gen = self.convert_mol_to_blk(self.t, blk_type, mold_sum)
                            today_inventory[blk_type - 1] += blk_gen
                        today_inventory[blk_type - 1] -= blk_order
                        if today_inventory[blk_type - 1] > 0:
                            self.tot_surplus += today_inventory[blk_type - 1]
                        elif today_inventory[blk_type - 1] < 0:
                            self.tot_shortage -= today_inventory[blk_type - 1]
                self.orderday_diff.append(today_inventory)
            self.daily_inventory.append(today_inventory) 


    # True if the current time is 6pm (i.e., delivery time)
    def is_delivery_time(self):
        return self.t % 24 == 18

    # Get today's order list
    # [blk_1_order, blk_2_order, blk_3_order, blk_4_order]
    def get_order_today(self, t=None):
        if t is None:
            t = self.t
        order_vals = self._order.loc[int(t / 24)]
        return order_vals.to_list()[1:]

    def convert_mol_to_blk(self, t, blk_type, mol):
        idx = 0  # April
        if 720 <= t <= 1463:  # May
            idx = 1
        elif t >= 1464:  # June
            idx = 2

        cnt = 506 if blk_type <= 2 else 400

        return int(self._cutyield.loc[idx][f'BLK_{blk_type}'] / 100 * mol * cnt)



    # line: 0 or 1
    # event_decision: 0: check, 1: process, 2: stop, 3: change
    # Reset T as 0 if reset_T == True
    def update_line_state(self, line, event_action, reset_T=True):
        if self.line_states[line] != event_action:
            self.line_states[line] = event_action
            if reset_T:
                self.line_Ts[line] = 0

    # Return list of events
    # [(time, event_name, duration), ...]
    def get_event_list(self, line):
        event_list = self.line_eventlists[line]
        state_list = []
        last_t = event_list[0][0]       
        last_state = event_list[0][1]
        last_type = event_list[0][2]
        brick_type_order = [last_type]
        for (t, st, ty, mld) in event_list[1:]:
            if ty is not None:
                brick_type_order.append(ty)
            if st != None and st != last_state:
                if last_state == 0:  # CHECK
                    state_list.append((last_t, f'CHECK_{last_type}', t-last_t))
                elif last_state == 1:  # PROCESS
                    state_list.append((last_t, f'PROCESS', t-last_t))
                elif last_state == 2:  # STOP
                    state_list.append((last_t, f'STOP', t-last_t))
                elif last_state == 3:  # CHANGE
                    state_list.append((last_t, f'CHANGE_{brick_type_order[-2]}{brick_type_order[-1]}', t-last_t))
                last_t, last_state = t, st
                if ty is not None:
                    last_type = ty
        if last_state == 0:  # CHECK
            state_list.append((last_t, f'CHECK_{last_type}', 2184-last_t))
        elif last_state == 1:  # PROCESS
            state_list.append((last_t, f'PROCESS', 2184-last_t))
        elif last_state == 2:  # STOP
            state_list.append((last_t, f'STOP', 2184-last_t))
        elif last_state == 3:  # CHANGE
            state_list.append((last_t, f'CHANGE_{brick_type_order[-2]}{brick_type_order[-1]}', 2184-last_t))
        return state_list

    def save_submission(self, file_name):
        line_type = ['Event_A', 'Event_B']
        mol_type = ['MOL_A', 'MOL_B']
        submission = self._submission
        submission.loc[:, 'PRT_1':'PRT_4'] = 0
        ####
        for line in [0, 1]:
            # line state
            for t, line_st, line_ts in self.get_event_list(line):
                submission.loc[t:t + line_ts, line_type[line]] = line_st
            # num_mol
            for t, _, _, num_mol in self.line_eventlists[line]:
                if num_mol is not None:
                    submission.loc[t, mol_type[line]] = num_mol
        ###
        _, df_stock = simulator.get_score(submission)
        # PRT 개수 계산
        PRTs = df_stock[['PRT_1', 'PRT_2', 'PRT_3', 'PRT_4']].values
        PRTs = (PRTs[:-1] - PRTs[1:])[24 * 23:]
        PRTs = np.ceil(PRTs * 1.1)
        PAD = np.zeros((24 * 23 + 1, 4))
        PRTs = np.append(PRTs, PAD, axis=0).astype(int)
        # Submission 파일에 PRT 입력
        submission.loc[:, 'PRT_1':'PRT_4'] = PRTs
        submission.to_csv(file_name, index=False)