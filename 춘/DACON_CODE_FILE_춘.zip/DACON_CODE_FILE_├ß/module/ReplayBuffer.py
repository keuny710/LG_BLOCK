from collections import deque
import numpy as np
import math, random

class ReplayBuffer(object):
    def __init__(self, capacity): 
        self.buffer = deque(maxlen=capacity)

    def push(self, state, action, reward, next_state, done, mask): 
        state = np.expand_dims(state, 0) 
        next_state = np.expand_dims(next_state, 0) 
        mask = np.expand_dims(mask, 0)

        self.buffer.append((state, action, reward, next_state, done, mask))

    def sample(self, batch_size):
        state, action, reward, next_state, done, mask = zip(*random.sample(self.buffer, batch_size))
        return np.concatenate(state), action, reward, np.concatenate(next_state), done, np.concatenate(mask)

    def __len__(self):
        return len(self.buffer)
