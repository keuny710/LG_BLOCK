import math
import datetime
import pandas as pd
import numpy as np
import copy

class Data():
    def __init__(self):
        self.order = pd.read_csv('./data/order.csv')
        self.init_stock = pd.read_csv('./data/stock.csv')
        self.submission_ini = pd.read_csv('./data/sample_submission.csv')
        self.PRT_names = list(self.init_stock.columns[0:4])
        self.MOL_names = list(self.init_stock.columns[4:8])
        self.BLK_names = list(self.init_stock.columns[8:12])
        self.date = list(self.order['time'])
        self.cal_init_stock()
        self.cal_need_mol()
        self.make_data_for_RL()
    def cal_init_stock(self):
        # 처음 기초 재고
        init_stock_dic = {
            name : stock
            for name, stock in zip(self.MOL_names+self.BLK_names,self.init_stock.loc[0,'MOL_1':'BLK_4'])
        }
        # MOL 1개당 BLK로 환산되는 비율
        mol_to_blk = {
            1: 506 * 0.851,
            2: 506 * 0.901,
            3: 400 * 0.71,
            4: 400 * 0.70
        }
        # 기초 재고 중에서 MOL은 BLK로 환산
        for number in range(1,5):
            init_stock_dic[f'BLK_{number}'] += math.floor(init_stock_dic[f'MOL_{number}'] * mol_to_blk[number])
            init_stock_dic[f'MOL_{number}'] = 0
        order_dic = {}
        for time, BLK1, BLK2, BLK3, BLK4 in zip(self.order['time'],self.order['BLK_1'],self.order['BLK_2'],self.order['BLK_3'],self.order['BLK_4']):
            order_dic[time] = {
                'BLK_1' : BLK1,
                'BLK_2' : BLK2,
                'BLK_3' : BLK3,
                'BLK_4' : BLK4
            }
        # 재고가 있으면 가장 최근 오더를 대체
        for d in self.date:
            for blk_name in self.BLK_names:
                if order_dic[d][blk_name] > 0 and init_stock_dic[blk_name] > 0 :
                    if init_stock_dic[blk_name] > order_dic[d][blk_name] :
                        init_stock_dic[blk_name] -= order_dic[d][blk_name]
                        order_dic[d][blk_name] = 0
                    else:
                        order_dic[d][blk_name] -= init_stock_dic[blk_name]
                        init_stock_dic[blk_name] = 0
        self.order_dic = order_dic
    def cal_need_mol(self):
    # BLK 1개를 만들기 위해 필요한 MOL 비율
        blk_to_mol = {
            1 : 0.851 * 506 * 0.975,
            2 : 0.901 * 506 * 0.975,
            3 : 0.71 * 400 * 0.975,
            4 : 0.70 * 400 * 0.975
        }
        # MOL이 BLK로 만들어지기 위해 48시간이 소모되므로 오더가 있는 날 이틀전 필요한 몰 개수 계산
        need_mol_dic = {}
        for mol_produce_date, order_date in zip(['0000-00-00']*2 + self.date, self.date + self.date[-2:]):
            need_mol_dic[mol_produce_date] = {}
            daily_mol_sum = 0
            for number in range(1,5):
                daily_mol_sum += math.ceil(self.order_dic[order_date][f'BLK_{number}'] / blk_to_mol[number])
                if self.order_dic[order_date][f'BLK_{number}'] > 0 :
                    need_mol_dic[mol_produce_date][f'MOL_{number}'] = math.ceil(self.order_dic[order_date][f'BLK_{number}'] / blk_to_mol[number])
                else:
                    need_mol_dic[mol_produce_date][f'MOL_{number}'] = 0
            if daily_mol_sum > 150:
                need_mol_dic[mol_produce_date]['make_more'] = True
            else:
                need_mol_dic[mol_produce_date]['make_more'] = False
        self.need_mol_dic = need_mol_dic

        need_mol_cumulative_l = {}
        mol = { i : 0 for i in range(1,5)}
        for d in self.date:
            need_mol_cumulative_l[d] = []
            for i in range(1,5):
                mol[i] += need_mol_dic[d][f'MOL_{i}']
                need_mol_cumulative_l[d].append(mol[i])

        # 하루에 생산해야하는 총 몰 개수가 200개가 넘는 경우 3일 먼저 더 생산필요
        for idx, d in enumerate(self.date):
            for i in range(0,4):
                if need_mol_dic[d]['make_more'] == True and idx >= 3:
                    need_mol_cumulative_l[self.date[idx-3]][i] = need_mol_cumulative_l[d][i]

        # 각 시간별로 최소한 생산했어야하는 MOL의 총 개수
        need_mol_cumulative_per_hour = {}
        cur_day = 0
        for s in range(len(self.submission_ini['time'])):
            if s % 24 >= 0 and s % 24 <= 18 :
                need_mol_cumulative_per_hour[s] = need_mol_cumulative_l[self.date[cur_day]]
            elif cur_day == 90:
                need_mol_cumulative_per_hour[s] = need_mol_cumulative_l[self.date[cur_day]]
            elif s % 24 >= 19 and s % 24 <= 23:
                need_mol_cumulative_per_hour[s] = need_mol_cumulative_l[self.date[cur_day+1]]
            if s % 24 == 23 :
                cur_day += 1
        self.need_mol_cumulative_per_hour = need_mol_cumulative_per_hour
    def make_data_for_RL(self):
        check_per_hour = {}
        for s in range(len(self.submission_ini['time'])):
            check_per_hour[s] = self.need_mol_cumulative_per_hour[s]
        brick_mask = {}
        for idx, time in enumerate(list(self.submission_ini['time'][2*24:]) + list(self.submission_ini['time'][-2*24:])):
            check_mask = self.need_mol_dic[time[:10]]
            brick_mask[idx] = []
            for val in list(check_mask.values())[:-1]:
                if val > 0 :
                    brick_mask[idx].append(1)
                else:
                    brick_mask[idx].append(0)
            if np.all(np.array(brick_mask[idx])== 0) and idx!=0:
                brick_mask[idx] = brick_mask[idx-1]
            else:
                brick_mask[idx] = np.array(brick_mask[idx])
        self.check_per_hour = check_per_hour
        self.brick_mask = brick_mask

