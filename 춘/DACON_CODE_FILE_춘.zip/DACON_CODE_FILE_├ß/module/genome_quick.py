import os
import pandas as pd
import numpy as np
import math
import datetime

import copy
from pathlib import Path
from module.sim_block import Simulator
from module.Data import Data

simulator = Simulator()
submission_ini = pd.read_csv(os.path.join(Path(__file__).resolve().parent, 'sample_submission.csv'))
order_ini = pd.read_csv(os.path.join(Path(__file__).resolve().parent, 'order.csv'))

event_map = {0: 'CHECK_1', 1: 'CHECK_2', 2: 'CHECK_3', 3: 'CHECK_4', 4: 'PROCESS'}

class Net():
    def __init__(self, input_len, output_len, h1=50, h2=50, h3=50):
        # 히든레이어 노드 개수
        self.hidden_layer1 = h1
        self.hidden_layer2 = h2
        self.hidden_layer3 = h3

        # 가중치
        self.w1 = np.random.randn(input_len, self.hidden_layer1)
        self.w2 = np.random.randn(self.hidden_layer1, self.hidden_layer2)
        self.w3 = np.random.randn(self.hidden_layer2, self.hidden_layer3)
        self.w4 = np.random.randn(self.hidden_layer3, output_len)

    def forward(self, inputs, mask=None):
        # Event 신경망
        net = np.matmul(inputs, self.w1)
        net = self.linear(net)
        net = np.matmul(net, self.w2)
        net = self.linear(net)
        net = np.matmul(net, self.w3)
        net = self.sigmoid(net)
        net = np.matmul(net, self.w4)
        net = self.softmax(net)
        if mask is not None:
            net += 1
            net = net * mask
            out = event_map[np.argmax(net)]
            return out
        else:
            out = np.argmax(net)
            out /= 2
            return out

    def sigmoid(self, x):
        return 1 / (1 + np.exp(-x))

    def softmax(self, x):
        return np.exp(x) / np.sum(np.exp(x), axis=0)

    def linear(self, x):
        return x


class Machine():
    def __init__(self):
        # Event 종류 추가
        self.mask = np.zeros([5], np.bool)  # 가능한 이벤트 검사용 마스크

        self.check_time = 28  # 28시간 검사를 완료했는지 검사, CHECK Event시 -1, processtime_time >=98 이면 28
        self.process = 0  # 생산 가능 여부, 0 이면 28 시간 검사 필요
        self.process_mode = 0  # 생산 물품 번호 1~4, stop시 0
        self.process_time = 0  # 생산시간이 얼마나 지속되었는지 검사, PROCESS +1, CHANGE +1, 최대 140

    def update_mask(self):
        self.mask[:] = False
        if self.process == 0:
            if self.check_time == 28:
                self.mask[:4] = True
            if self.check_time < 28:
                self.mask[self.process_mode] = True
        if self.process == 1:
            self.mask[4] = True
            if self.process_time > 98:
                self.mask[:4] = True

    def event_effect(self, out):
        if out == 'CHECK_1':
            if self.process == 1:
                self.process = 0
                self.check_time = 28
            self.check_time -= 1
            self.process_mode = 0
            self.stop = 0
            self.stop_time = 0
            if self.check_time == 0:
                self.process = 1
                self.process_time = 0
        elif out == 'CHECK_2':
            if self.process == 1:
                self.process = 0
                self.check_time = 28
            self.check_time -= 1
            self.process_mode = 1
            self.stop = 0
            self.stop_time = 0
            if self.check_time == 0:
                self.process = 1
                self.process_time = 0
        elif out == 'CHECK_3':
            if self.process == 1:
                self.process = 0
                self.check_time = 28
            self.check_time -= 1
            self.process_mode = 2
            self.stop = 0
            self.stop_time = 0
            if self.check_time == 0:
                self.process = 1
                self.process_time = 0
        elif out == 'CHECK_4':
            if self.process == 1:
                self.process = 0
                self.check_time = 28
            self.check_time -= 1
            self.process_mode = 3
            self.stop = 0
            self.stop_time = 0
            if self.check_time == 0:
                self.process = 1
                self.process_time = 0
        elif out == 'PROCESS':
            self.process_time += 1
            self.change_type = 0
            if self.process_time == 140:
                self.process = 0
                self.check_time = 28

    def init_variables(self):
        # 변수 초기화
        self.check_time = 28
        self.process = 0
        self.process_mode = 0
        self.process_time = 0

        # change 추가
        self.change_type = 0
        self.change_time = 0


class Genome():
    def __init__(self, score_ini, input_len, output_len_1, output_len_2, input_dic, h1=50, h2=50, h3=50):
        # 평가 점수 초기화
        self.score = score_ini
        
        # machine A의 이벤트와 MOL 수량에 대한 신경망
        self.m1_event_net = Net(input_len, output_len_1, h1, h2, h3)
        self.m1_amount_net = Net(input_len, output_len_2, h1, h2, h3)

        # machine B의 이벤트와 MOL 수량에 대한 신경망
        self.m2_event_net = Net(input_len, output_len_1, h1, h2, h3)
        self.m2_amount_net = Net(input_len, output_len_2, h1, h2, h3)
        
        self.machine_A = Machine()
        self.machine_B = Machine()
        
        # 미리 만들어놓은 input을 사용함. 
        self.input_dic = input_dic
        
    def make_mol_info(self, s, mol):
        
        # 필요한 MOL수 - 생산한 MOL수 계산
        data = self.data
        need_mol_state = np.array(data.need_mol_cumulative_per_hour[s])
        produce_state = np.array([mol[1],mol[2],mol[3],mol[4]])
        current_state = need_mol_state - produce_state
    
        return current_state

    def predict(self, data):
        
        self.data = data
        self.submission = submission_ini
         
        mol = {1:0, 2:0, 3:0, 4:0}
        
        prt_ini_l = [0 for _ in range(self.submission.shape[0])]
        
        event_A_l = []
        mol_A_l = []
        event_B_l = []
        mol_B_l = []

        machine_A_state = 0
        machine_B_state = 0

        for s in range(self.submission.shape[0]):
            self.machine_A.update_mask()
            self.machine_B.update_mask()
            
            # 미리 만들어 놓은 input을 사용하여 유전알고리즘 속도를 증가시킴
            inputs = self.input_dic[s]

            machine_1_event = self.m1_event_net.forward(inputs, self.machine_A.mask)
            machine_1_amount = self.m1_amount_net.forward(inputs)

            machine_2_event = self.m2_event_net.forward(inputs, self.machine_B.mask)
            machine_2_amount = self.m2_amount_net.forward(inputs)

            self.machine_A.event_effect(machine_1_event)
            self.machine_B.event_effect(machine_2_event)
            
            try:
                machine_A_state = int(machine_1_event[-1])
            except:
                pass
            
            try:
                machine_B_state = int(machine_2_event[-1])
            except:
                pass
            
            current_state = self.make_mol_info(s, mol)
            
            event_A_l.append(machine_1_event)
            event_B_l.append(machine_2_event)
            
            if machine_1_event == 'PROCESS' and s > 23*24 : # 23일간 MOL = 0
                
                need_mol = current_state[machine_A_state-1]
                
                if need_mol <= 0 :
                    mol_A_l.append(0)
                elif 0 < need_mol < 5.85:
                    mol_A_l.append(machine_1_amount)
                    mol[machine_A_state] += machine_1_amount
                elif need_mol >= 5.85:
                    mol_A_l.append(5.85)
                    mol[machine_A_state] += 5.85
            else:
                mol_A_l.append(0)
                
            if machine_2_event == 'PROCESS' and s > 23*24: # 23일간 MOL = 0
                need_mol = current_state[machine_B_state-1]
                if need_mol <= 0 :
                    mol_B_l.append(0)
                elif 0 < need_mol < 5.85:
                    mol_B_l.append(machine_2_amount)
                    mol[machine_B_state] += machine_2_amount
                elif need_mol >= 5.85:
                    mol_B_l.append(5.85)
                    mol[machine_B_state] += 5.85
            else:
                mol_B_l.append(0)

        for i in range(1,5):
            self.submission[f'PRT_{i}'] = prt_ini_l   
            
        self.submission['Event_A'] = event_A_l
        self.submission['MOL_A'] = mol_A_l
        
        self.submission['Event_B'] = event_B_l
        self.submission['MOL_B'] = mol_B_l

        self.machine_A.init_variables()
        self.machine_B.init_variables()

        return self.submission

def genome_score(genome):
    data = Data()
    submission = genome.predict(data)
    genome.submission = submission
    genome.score, _ = simulator.get_score(submission)
    return genome
