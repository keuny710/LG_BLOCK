-------root-------

data : 기본적으로 공정에 사용되는, 제공된 데이터 폴더

module : main파일을 실행시키기 위한 python모듈 폴더

RL_submission : Action Transfer Reinforcement Learning을 위해 높은 score가 나온 submission을 모아놓은 폴더

main_Genome.ipynb : baseline코드에서 발전된 유전 알고리즘을 실행하기 위한 main파일

main_RL : Action Transfer Reinforcement Learning을 실행하기 위한 main파일

-------module-------

Data.py : 기본적인 데이터에 대한 전처리와 학습에 사용할 데이터를 만들기 위한 모듈

Environment.py : 강화학습에서 사용할 환경(Env)을 구축하기 위한 모듈

genome_quick.py : 보다 빠르게 학습할 수 있는 유전알고리즘 모듈

model.py : 강화학습에서 사용할 네트워크들에 대한 모듈 

ReplayBuffer.py : 강화학습에서 사용할 Buffer에 대한 모듈

sim_block.py : baseline의 simulator보다 10배 빠른 simulator모듈

simulator.py : baseline의 simulator 모듈

train.py : 네트워크를 학습하기 위한 모듈

max_count.csv : 일별 기계당 최대 생산량 데이터

order.csv : 주문 데이터

sample_submission : 공정 스케줄 양식 데이터

stock.csv : 기초재고 데이터

-------data-------

change_time.py : Mol type을 바꾸는데 드는 시간 데이터

cut_yield.csv : 월별 Mol -> BLK 수율 데이터

max_count.csv : 일별 기계당 최대 생산량 데이터

order.csv : 주문 데이터

sample_submission : 공정 스케줄 양식 데이터

stock.csv : 기초재고 데이터

